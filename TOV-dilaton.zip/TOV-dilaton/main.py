#!/usr/bin/env python
from TOV import *
import matplotlib 
import matplotlib.pyplot as plt
import scipy.constants as cst

def test():
    rhoInit = 1000*cst.eV*10**6/(cst.c**2*cst.fermi**3)
    radiusStep = 100
    PsiInit = 0
    PhiInit = 1
    radiusInit = 0.000001
    option = 1
    dilaton = False
    tov = TOV(radiusInit, rhoInit, PsiInit, PhiInit, radiusStep, option, dilaton)
    tov.Compute()
    tov.PlotEvolution()
    print(tov.radiusStar)
    print(tov.massStar)
    print(tov.pressureStar)
    print(tov.initPressure)

def plotDensityMass(PsiInit, PhiInit, option, dilaton):
    radiusStep = 100
    rhoMin = 100
    rhoMax = 5000
    radiusInit = 0.000001

    massStar = []
    rho = [x*cst.eV*10**6/(cst.c**2*cst.fermi**3) for x in range(rhoMin,rhoMax,20)]
    for iRho in rho:
        rhoInit = iRho
        tov = TOV(radiusInit, rhoInit, PsiInit, PhiInit, radiusStep, option, dilaton)
        tov.Compute()
        massStar.append(tov.massStar)
    if option == 0:
        lagrangianLabel = 'T'
    elif option == 1:
        lagrangianLabel = '$-\\rho c^2$'
    elif option == 2:
        lagrangianLabel = 'P'         
    else:
        print('not a valid option')
    if dilaton:
        plt.plot([x/(cst.eV*10**6/(cst.c**2*cst.fermi**3)) for x in rho], [x/(1.989*10**30) for x in massStar], label='$\Phi_0=$%.1f' %PhiInit)
    else:
        plt.plot([x/(cst.eV*10**6/(cst.c**2*cst.fermi**3)) for x in rho], [x/(1.989*10**30) for x in massStar], label='GR')        
    plt.xlabel('Density $\\rho$ ($Mev/fm^3$)')
    plt.ylabel('Mass $M/M_{\odot}$')
    plt.legend()
        
def plotRadiusMass(PsiInit, PhiInit, option, dilaton):
    radiusStep = 100
    rhoMin = 100
    rhoMax = 5000
    radiusInit = 0.000001

    massStar = []
    radiusStar = []
    rho = [x*cst.eV*10**6/(cst.c**2*cst.fermi**3) for x in range(rhoMin,rhoMax,20)]
    for iRho in rho:
        rhoInit = iRho
        tov = TOV(radiusInit, rhoInit, PsiInit, PhiInit, radiusStep, option, dilaton)
        tov.Compute()
        #if (tov.radiusStar>2000 and tov.radiusStar<30000):
        massStar.append(tov.massStar)
        radiusStar.append(tov.radiusStar)
    if option == 0:
        lagrangianLabel = 'T'
    elif option == 1:
        lagrangianLabel = '$-\\rho c^2$'
    elif option == 2:
        lagrangianLabel = 'P'         
    else:
        print('not a valid option')
    if dilaton:
        plt.plot([x/1000 for x in radiusStar], [x/(1.989*10**30) for x in massStar], label='$\Phi_0=$%.1f' %PhiInit)
    else:
        plt.plot([x/1000 for x in radiusStar], [x/(1.989*10**30) for x in massStar], label='GR')
    plt.xlabel('Radius R (km)')
    plt.ylabel('Mass $M/M_{\odot}$')
    plt.legend()

#test()
def main():
    #test()
    figure()
    plotDensityMass(0, 1, 0, False)
    plotDensityMass(0, 1, 1, True)
    plotDensityMass(0, 2, 1, True)
    plotDensityMass(0, 4, 1, True)
    plotDensityMass(0, 6, 1, True)
    plt.show()
    figure()
    plotRadiusMass(0, 1, 0, False)
    plotRadiusMass(0, 1, 1, True)
    plotRadiusMass(0, 2, 1, True)
    plotRadiusMass(0, 4, 1, True)
    plotRadiusMass(0, 6, 1, True)
    plt.show()
    
main()